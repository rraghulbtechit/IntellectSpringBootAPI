package com.intellect.dao;

public class UserDaoImpl implements IUserDao {

}
