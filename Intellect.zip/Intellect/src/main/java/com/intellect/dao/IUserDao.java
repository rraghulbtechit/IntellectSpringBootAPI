package com.intellect.dao;

public interface IUserDao {

}
