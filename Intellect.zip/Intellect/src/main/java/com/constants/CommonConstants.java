package com.constants;
/**
 * 
 * @author raghulr
 *
 */
public class CommonConstants {

	public static final Integer OK 				= 200;
	public static final String SUCCESS			= "Success";
	
}
