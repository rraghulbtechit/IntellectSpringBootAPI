Intellect Spring boot apis
